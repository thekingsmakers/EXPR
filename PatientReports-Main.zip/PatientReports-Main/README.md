# Patient Reports Management System

A Flask-based web application for managing patient medical reports with DICOM viewing capabilities through Apache Guacamole and syngo fastView.

## Features

- 📤 **File Upload**: Drag-and-drop interface for uploading patient reports
- 🔍 **Search & View**: Search by Medical Record Number (MRN) and view files
- 🏥 **DICOM Support**: View DICOM files through remote syngo fastView
- 📊 **Dashboard**: Separate interfaces for upload and doctor viewing
- 🔐 **Secure**: Input validation and secure file handling

## Quick Start

### Prerequisites

- Python 3.8+
- Apache Guacamole server running
- syngo fastView installed on remote Windows machine
- Network share configured (see Network Setup below)

### Installation

1. **Clone and install dependencies:**
   ```bash
   git clone <repository-url>
   cd PatientReports
   pip install -r requirements.txt
   ```

2. **Configure environment variables:**
   ```bash
   # Create .env file or set environment variables
   export GUACAMOLE_BASE_URL=http://192.168.1.104:32768/
   export GUACAMOLE_USERNAME=guacaadmin
   export GUACAMOLE_PASSWORD=guacaadmin
   export SHARED_FOLDER_PATH=\\\\server\\shared\\patient-files
   ```

3. **Run the application:**
   ```bash
   python app.py
   ```

4. **Access the application:**
   - Upload Dashboard: http://localhost:5000/upload
   - Doctor Dashboard: http://localhost:5000/doctor

## Network Setup

For DICOM files to be accessible from the remote Windows session, you need to set up a network share:

### Option 1: Windows Network Share

1. **Create a shared folder on your server:**
   ```cmd
   # On Windows server
   mkdir C:\SharedPatientFiles
   net share PatientFiles=C:\SharedPatientFiles /grant:everyone,full
   ```

2. **Set the environment variable:**
   ```bash
   export SHARED_FOLDER_PATH=\\\\server\\PatientFiles
   ```

### Option 2: Samba Share (Linux)

1. **Install and configure Samba:**
   ```bash
   sudo apt install samba
   sudo mkdir /shared/patient-files
   sudo chmod 777 /shared/patient-files
   ```

2. **Add to /etc/samba/smb.conf:**
   ```ini
   [PatientFiles]
   path = /shared/patient-files
   browseable = yes
   read only = no
   guest ok = yes
   ```

3. **Restart Samba:**
   ```bash
   sudo systemctl restart smbd
   ```

4. **Set the environment variable:**
   ```bash
   export SHARED_FOLDER_PATH=\\\\server\\PatientFiles
   ```

### Option 3: Docker Volume (if using Docker)

1. **Update docker-compose.yml:**
   ```yaml
   volumes:
     - ./data:/shared/patient-files
   ```

2. **Set the environment variable:**
   ```bash
   export SHARED_FOLDER_PATH=/shared/patient-files
   ```

## Configuration

### Network Configuration

The easiest way to update IP addresses is to edit `network_config.py`:

```python
# Your machine's IP address (WiFi IP)
HOST_IP = "192.168.1.104"  # ← Change this to your IP

# Guacamole server configuration
GUACAMOLE_IP = HOST_IP  # Usually same as host IP
GUACAMOLE_PORT = 32768

# Flask application configuration
FLASK_IP = HOST_IP  # Usually same as host IP
FLASK_PORT = 5000
```

### Quick IP Update

Use the IP update script to easily change IP addresses:

```bash
python update_ip.py
```

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `GUACAMOLE_BASE_URL` | Guacamole server URL | Auto-generated from network_config.py |
| `GUACAMOLE_USERNAME` | Guacamole username | `guacaadmin` |
| `GUACAMOLE_PASSWORD` | Guacamole password | `guacaadmin` |
| `GUACAMOLE_CONNECTION_ID` | Guacamole connection ID | `SYngoServer` |
| `SHARED_FOLDER_PATH` | Network share path for files | `None` |
| `UPLOAD_FOLDER` | Local upload directory | `data` |
| `MAX_FILE_SIZE` | Maximum file size in bytes | `52428800` (50MB) |
| `FLASK_DEBUG` | Enable debug mode | `True` |
| `FLASK_HOST` | Host to bind to | `0.0.0.0` |
| `FLASK_PORT` | Port to bind to | `5000` |

### Finding Your IP Address

To find your machine's IP address:

**Windows:**
```cmd
ipconfig
```
Look for "IPv4 Address" under your WiFi adapter.

**Linux/Mac:**
```bash
ifconfig
# or
ip addr
```

### Guacamole Setup

1. **Install Apache Guacamole** following the [official documentation](https://guacamole.apache.org/doc/gug/installing-guacamole.html)

2. **Create a connection** to your Windows machine with syngo fastView

3. **Set the connection ID** in your environment variables

## API Endpoints

### Health Check
- `GET /api/health` - Application health status
- `GET /api/guacamole/status` - Guacamole connection status

### File Management
- `POST /api/upload` - Upload files for a patient
- `GET /api/search/<mrn>` - Search files by MRN
- `GET /api/mrns` - Get all available MRNs
- `GET /files/<mrn>/<filename>` - Serve files
- `GET /api/file-info/<mrn>/<filename>` - Get file information

### DICOM Viewer
- `GET /dicom-viewer/<mrn>/<filename>` - Open DICOM file in syngo

## Security Features

- ✅ Input validation for MRN values
- ✅ Secure filename handling
- ✅ File type validation
- ✅ File size limits
- ✅ Directory traversal protection
- ✅ Environment variable configuration

## Troubleshooting

### Guacamole Connection Issues

1. **Check if Guacamole is running:**
   ```bash
   curl http://192.168.1.104:32768/guacamole/
   ```

2. **Verify credentials:**
   ```bash
   curl -X POST http://192.168.1.104:32768/guacamole/api/tokens \
     -H "Content-Type: application/json" \
     -d '{"username":"guacaadmin","password":"guacaadmin"}'
   ```

3. **Check connection status:**
   ```bash
   curl http://192.168.1.104:5000/api/guacamole/status
   ```

### File Access Issues

1. **Verify network share is accessible:**
   ```cmd
   # On Windows remote machine
   dir \\server\PatientFiles
   ```

2. **Check file permissions:**
   ```bash
   ls -la /shared/patient-files
   ```

3. **Test file path in syngo:**
   - Open syngo fastView
   - Try to navigate to the network path
   - Verify files are visible

## Development

### Running in Development Mode

```bash
export FLASK_DEBUG=True
python app.py
```

### Running with Docker

```bash
docker-compose up -d
```

### Testing

```bash
# Health check
curl http://localhost:5000/api/health

# Upload test file
curl -X POST http://localhost:5000/api/upload \
  -F "file=@test.pdf" \
  -F "mrn=TEST123"
```

## License

This project is licensed under the MIT License - see the LICENSE file for details. 
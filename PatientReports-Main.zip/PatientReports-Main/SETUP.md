# 🚀 Setup Guide - Medical Reports Platform

This guide will help you set up and run the Medical Reports Platform on your system.

## 📋 Prerequisites

- **Python 3.8 or higher**
- **Web browser** (Chrome, Firefox, Safari, Edge)
- **Apache Guacamole** (for DICOM viewing - optional)
- **syngo fastView** (for DICOM files - optional)

## 🛠 Installation Options

### Option 1: Quick Start (Windows)

1. **Download and extract** the project files
2. **Double-click** `start.bat`
3. **Wait** for the application to start
4. **Open** http://localhost:5000 in your browser

### Option 2: Manual Setup

#### Step 1: Install Python Dependencies

```bash
# Create virtual environment
python -m venv venv

# Activate virtual environment
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate

# Install requirements
pip install -r requirements.txt
```

#### Step 2: Configure the Application

1. **Edit `config.py`** with your settings:
   ```python
   # Update these values for your environment
   GUACAMOLE_BASE_URL = "http://your-guacamole-server"
   GUACAMOLE_CONNECTION_ID = "your-connection-id"
   ```

2. **Set environment variables** (optional):
   ```bash
   export SECRET_KEY="your-secure-secret-key"
   export FLASK_DEBUG="True"
   ```

#### Step 3: Run the Application

```bash
# Start with sample data
python run.py

# Or start directly
python app.py
```

### Option 3: Docker Deployment

#### Using Docker Compose (Recommended)

```bash
# Build and start
docker-compose up -d

# View logs
docker-compose logs -f

# Stop
docker-compose down
```

#### Using Docker directly

```bash
# Build image
docker build -t medical-reports .

# Run container
docker run -p 5000:5000 -v $(pwd)/data:/app/data medical-reports
```

## 🏥 DICOM Integration Setup

### Prerequisites for DICOM Viewing

1. **Apache Guacamole Server**
   - Install Guacamole on your server
   - Configure a Windows connection
   - Set up file transfer capabilities

2. **Windows VM with syngo fastView**
   - Install syngo fastView
   - Configure shared folder access
   - Test Guacamole connection

### Configuration Steps

1. **Update Guacamole Settings** in `config.py`:
   ```python
   GUACAMOLE_BASE_URL = "http://your-guacamole-server"
   GUACAMOLE_CONNECTION_ID = "your-connection-id"
   ```

2. **Set up File Sharing**:
   - Map Flask `data/` directory to Windows shared folder
   - Ensure proper permissions for file access

3. **Test DICOM Integration**:
   - Upload a DICOM file
   - Click on it in the doctor dashboard
   - Verify Guacamole redirect works

## 📁 File Structure

```
PatientReports/
├── app.py                 # Main Flask application
├── config.py             # Configuration settings
├── run.py                # Startup script
├── sample_data.py        # Sample data generator
├── requirements.txt      # Python dependencies
├── Dockerfile           # Docker configuration
├── docker-compose.yml   # Docker Compose setup
├── start.bat            # Windows startup script
├── README.md            # Main documentation
├── SETUP.md             # This setup guide
├── .gitignore           # Git ignore rules
├── data/                # File storage (auto-created)
├── index.json           # File metadata (auto-created)
└── templates/           # HTML templates
    ├── base.html
    ├── upload.html
    ├── doctor.html
    └── dicom_redirect.html
```

## 🔧 Configuration Options

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `SECRET_KEY` | Flask secret key | Auto-generated |
| `FLASK_DEBUG` | Debug mode | `True` |
| `FLASK_HOST` | Server host | `0.0.0.0` |
| `FLASK_PORT` | Server port | `5000` |
| `GUACAMOLE_BASE_URL` | Guacamole server URL | `http://your-guacamole-server` |
| `GUACAMOLE_CONNECTION_ID` | Guacamole connection ID | `your-connection-id` |

### File Upload Settings

- **Maximum file size**: 50MB per file
- **Allowed extensions**: PDF, DOCX, XLSX, PNG, JPG, DICOM (.dcm), TXT, DOC, XLS
- **Storage**: File-based (no database required)

## 🧪 Testing the Application

### 1. Generate Sample Data

```bash
python sample_data.py
```

This creates:
- 10 sample MRNs
- Multiple file types per MRN
- Placeholder files for testing

### 2. Test Upload Dashboard

1. Go to http://localhost:5000/upload
2. Enter an MRN (e.g., "MRN12345")
3. Drag and drop or select files
4. Click "Upload Files"

### 3. Test Doctor Dashboard

1. Go to http://localhost:5000/doctor
2. Search for an MRN (e.g., "MRN12345")
3. Click on files to view them
4. Test different file types

### 4. Test DICOM Integration

1. Upload a DICOM file (.dcm)
2. Go to doctor dashboard
3. Click on the DICOM file
4. Verify Guacamole redirect

## 🔒 Security Considerations

### Production Deployment

1. **Change default secret key**:
   ```bash
   export SECRET_KEY="your-secure-random-key"
   ```

2. **Disable debug mode**:
   ```bash
   export FLASK_DEBUG="False"
   ```

3. **Use HTTPS**:
   - Set up SSL certificates
   - Configure reverse proxy (nginx)

4. **Add authentication** (if needed):
   - Implement user login
   - Add role-based access control

### File Security

- Files are stored in `data/` directory
- Filenames are sanitized
- File types are validated
- Size limits are enforced

## 🚨 Troubleshooting

### Common Issues

#### 1. Port Already in Use
```bash
# Check what's using port 5000
netstat -ano | findstr :5000  # Windows
lsof -i :5000                 # macOS/Linux

# Use different port
export FLASK_PORT=5001
```

#### 2. Permission Errors
```bash
# Ensure write permissions
chmod 755 data/
chmod 644 index.json
```

#### 3. DICOM Files Not Opening
- Verify Guacamole server is running
- Check connection ID is correct
- Ensure file sharing is configured
- Test Guacamole connection manually

#### 4. File Upload Fails
- Check file size (max 50MB)
- Verify file type is allowed
- Ensure data directory exists
- Check disk space

### Logs and Debugging

#### Enable Debug Mode
```bash
export FLASK_DEBUG="True"
```

#### View Application Logs
```bash
# Direct output
python app.py

# With Docker
docker-compose logs -f
```

#### Health Check
```bash
curl http://localhost:5000/api/health
```

## 📞 Support

### Getting Help

1. **Check the logs** for error messages
2. **Verify configuration** in `config.py`
3. **Test with sample data** using `sample_data.py`
4. **Check prerequisites** are installed

### Common Commands

```bash
# Start application
python run.py

# Generate sample data
python sample_data.py

# Health check
curl http://localhost:5000/api/health

# View all MRNs
curl http://localhost:5000/api/mrns

# Docker commands
docker-compose up -d
docker-compose logs -f
docker-compose down
```

## 🎯 Next Steps

After successful setup:

1. **Customize the UI** by editing templates
2. **Add authentication** for production use
3. **Configure backup** for data directory
4. **Set up monitoring** and logging
5. **Integrate with existing systems**

---

**🎉 Congratulations!** Your Medical Reports Platform is now running.

- **Upload Dashboard**: http://localhost:5000/upload
- **Doctor Dashboard**: http://localhost:5000/doctor
- **Health Check**: http://localhost:5000/api/health 
import re
from flask import Flask, render_template, request, jsonify, send_from_directory, redirect, url_for, flash
import os
import json
import uuid
from datetime import datetime
from werkzeug.utils import secure_filename
import mimetypes
import shutil
import requests
from config import Config

# Load environment variables from .env file if it exists
if os.path.exists('.env'):
    from dotenv import load_dotenv
    load_dotenv()

app = Flask(__name__)
app.config.from_object(Config)

# Ensure data directory exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

def validate_mrn(mrn):
    """Validate MRN format and security"""
    if not mrn or len(mrn.strip()) == 0:
        return False, "MRN cannot be empty"
    
    mrn = mrn.strip()
    
    # Check for potentially dangerous characters
    if re.search(r'[<>"\'\&]', mrn):
        return False, "MRN contains invalid characters"
    
    # Check length
    if len(mrn) > 50:
        return False, "MRN too long (max 50 characters)"
    
    # Check for directory traversal attempts
    if '..' in mrn or '/' in mrn or '\\' in mrn:
        return False, "MRN contains invalid path characters"
    
    return True, mrn

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

def load_index():
    """Load the file index from JSON"""
    if os.path.exists(app.config['INDEX_FILE']):
        with open(app.config['INDEX_FILE'], 'r') as f:
            return json.load(f)
    return {}

def save_index(index):
    """Save the file index to JSON"""
    with open(app.config['INDEX_FILE'], 'w') as f:
        json.dump(index, f, indent=2, default=str)

def get_file_type(filename):
    """Determine file type for display purposes"""
    ext = filename.rsplit('.', 1)[1].lower()
    if ext == 'dcm':
        return 'DICOM'
    elif ext in ['pdf']:
        return 'PDF'
    elif ext in ['docx', 'doc']:
        return 'Document'
    elif ext in ['xlsx', 'xls']:
        return 'Spreadsheet'
    elif ext in ['png', 'jpg', 'jpeg']:
        return 'Image'
    else:
        return 'Other'

def get_guacamole_token():
    """Get authentication token from Guacamole"""
    try:
        # Try the standard Guacamole REST API endpoint
        auth_url = f"{app.config['GUACAMOLE_BASE_URL'].rstrip('/')}/api/tokens"
        auth_data = {
            'username': app.config['GUACAMOLE_USERNAME'],
            'password': app.config['GUACAMOLE_PASSWORD']
        }
        
        response = requests.post(auth_url, json=auth_data, timeout=10)
        
        if response.status_code == 200:
            result = response.json()
            return result.get('authToken') or result.get('token')
        elif response.status_code == 401:
            app.logger.error("Guacamole authentication failed - invalid credentials")
            return None
        else:
            app.logger.error(f"Guacamole auth failed: {response.status_code} - {response.text}")
            return None
            
    except requests.exceptions.ConnectionError:
        app.logger.error("Cannot connect to Guacamole server - check if it's running")
        return None
    except requests.exceptions.Timeout:
        app.logger.error("Guacamole authentication timeout")
        return None
    except Exception as e:
        app.logger.error(f"Error getting Guacamole token: {e}")
        return None

def build_guacamole_url(mrn, filename):
    """Build Guacamole URL for DICOM viewing with proper authentication"""
    base_url = app.config['GUACAMOLE_BASE_URL'].rstrip('/')
    connection_id = app.config['GUACAMOLE_CONNECTION_ID']
    
    # For now, use the basic URL without authentication token
    # Most Guacamole installations don't expose the API for token generation
    return f"{base_url}/#/client/{connection_id}"

def get_file_path_for_syngo(mrn, filename):
    """Get the file path that should be accessible from the remote session"""
    # Check if we have a network share configured
    shared_folder = app.config.get('SHARED_FOLDER_PATH')
    
    if shared_folder and shared_folder != '\\\\server\\shared\\dicom-files':
        # Use the configured network share
        return os.path.join(shared_folder, mrn, filename)
    else:
        # Fallback to local path with instructions for manual setup
        local_path = os.path.join(app.config['UPLOAD_FOLDER'], mrn, filename)
        app.logger.warning(f"No network share configured. File path: {local_path}")
        return local_path

def validate_guacamole_connection():
    """Validate Guacamole connection and return status"""
    try:
        # Test basic connectivity - try multiple endpoints
        base_url = app.config['GUACAMOLE_BASE_URL'].rstrip('/')
        
        # Try the main Guacamole page
        response = requests.get(f"{base_url}/", timeout=5)
        
        if response.status_code == 200:
            return {
                'connected': True,
                'authenticated': False,  # We'll skip token auth for now
                'message': 'Connected to Guacamole server (manual login required)'
            }
        else:
            return {
                'connected': False,
                'authenticated': False,
                'message': f'Guacamole server responded with status {response.status_code}'
            }
    except requests.exceptions.ConnectionError:
        return {
            'connected': False,
            'authenticated': False,
            'message': 'Cannot connect to Guacamole server - check if it\'s running on http://localhost:32768/'
        }
    except Exception as e:
        return {
            'connected': False,
            'authenticated': False,
            'message': f'Error testing connection: {str(e)}'
        }

@app.route('/')
def index():
    """Redirect to upload dashboard"""
    return redirect(url_for('upload_dashboard'))

@app.route('/upload')
def upload_dashboard():
    """Upload dashboard for adding patient reports"""
    index = load_index()
    recent_mrns = list(index.keys())[-10:]  # Last 10 MRNs
    return render_template('upload.html', recent_mrns=recent_mrns)

@app.route('/doctor')
def doctor_dashboard():
    """Doctor dashboard for viewing patient reports"""
    index = load_index()
    all_mrns = list(index.keys())
    return render_template('doctor.html', all_mrns=all_mrns)

@app.route('/api/upload', methods=['POST'])
def upload_file():
    """API endpoint for file upload"""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files['file']
        mrn_raw = request.form.get('mrn', '').strip()
        
        # Validate MRN
        mrn_valid, mrn_result = validate_mrn(mrn_raw)
        if not mrn_valid:
            return jsonify({'error': mrn_result}), 400
        
        mrn = mrn_result
        
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if not allowed_file(file.filename):
            return jsonify({'error': 'File type not allowed'}), 400
        
        # Check file size
        file.seek(0, 2)  # Seek to end
        file_size = file.tell()
        file.seek(0)  # Reset to beginning
        
        if file_size > app.config['MAX_FILE_SIZE']:
            return jsonify({'error': 'File too large (max 50MB)'}), 400
        
        # Create MRN directory with additional security
        mrn_dir = os.path.join(app.config['UPLOAD_FOLDER'], mrn)
        
        # Ensure the path is within the upload folder (prevent directory traversal)
        if not os.path.abspath(mrn_dir).startswith(os.path.abspath(app.config['UPLOAD_FOLDER'])):
            return jsonify({'error': 'Invalid MRN path'}), 400
        
        os.makedirs(mrn_dir, exist_ok=True)
        
        # Save file with secure filename
        filename = secure_filename(file.filename)
        
        # Ensure filename is not empty after sanitization
        if not filename:
            return jsonify({'error': 'Invalid filename after sanitization'}), 400
        
        file_path = os.path.join(mrn_dir, filename)
        file.save(file_path)
        
        # Update index
        index = load_index()
        if mrn not in index:
            index[mrn] = []
        
        file_info = {
            'filename': filename,
            'original_name': file.filename,
            'upload_time': datetime.now().isoformat(),
            'file_size': file_size,
            'file_type': get_file_type(filename)
        }
        
        index[mrn].append(file_info)
        save_index(index)
        
        return jsonify({
            'success': True,
            'message': f'File uploaded successfully for MRN {mrn}',
            'mrn': mrn,
            'filename': filename
        })
        
    except Exception as e:
        app.logger.error(f"Upload error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@app.route('/api/search/<mrn>')
def search_mrn(mrn):
    """Search for files by MRN"""
    index = load_index()
    if mrn in index:
        return jsonify({
            'found': True,
            'files': index[mrn],
            'mrn': mrn
        })
    else:
        return jsonify({
            'found': False,
            'message': f'No files found for MRN {mrn}'
        })

@app.route('/api/mrns')
def get_all_mrns():
    """Get all available MRNs"""
    index = load_index()
    return jsonify({
        'mrns': list(index.keys()),
        'count': len(index)
    })

@app.route('/files/<mrn>/<filename>')
def serve_file(mrn, filename):
    """Serve files for preview"""
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], mrn, filename)
    if os.path.exists(file_path):
        return send_from_directory(os.path.join(app.config['UPLOAD_FOLDER'], mrn), filename)
    else:
        return jsonify({'error': 'File not found'}), 404

@app.route('/dicom-viewer/<mrn>/<filename>')
def dicom_viewer(mrn, filename):
    """Redirect to Guacamole session for DICOM viewing"""
    # Validate MRN
    mrn_valid, mrn_result = validate_mrn(mrn)
    if not mrn_valid:
        return jsonify({'error': mrn_result}), 400
    
    # Check if file exists
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], mrn, filename)
    if not os.path.exists(file_path):
        return jsonify({'error': 'File not found'}), 404
    
    # Check Guacamole connection
    guacamole_status = validate_guacamole_connection()
    
    guacamole_url = build_guacamole_url(mrn, filename)
    syngo_file_path = get_file_path_for_syngo(mrn, filename)
    
    return render_template('dicom_redirect.html', 
                         guacamole_url=guacamole_url, 
                         mrn=mrn, 
                         filename=filename,
                         file_path=syngo_file_path,
                         guacamole_status=guacamole_status)

@app.route('/api/file-info/<mrn>/<filename>')
def get_file_info(mrn, filename):
    """Get detailed file information"""
    index = load_index()
    if mrn in index:
        for file_info in index[mrn]:
            if file_info['filename'] == filename:
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], mrn, filename)
                if os.path.exists(file_path):
                    file_info['exists'] = True
                    file_info['full_path'] = file_path
                    return jsonify(file_info)
    
    return jsonify({'error': 'File not found'}), 404

@app.route('/api/health')
def health_check():
    """Health check endpoint"""
    # Check Guacamole connection
    guacamole_status = validate_guacamole_connection()
    
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'version': '1.0.0',
        'guacamole': guacamole_status,
        'data_directory': os.path.exists(app.config['UPLOAD_FOLDER']),
        'index_file': os.path.exists(app.config['INDEX_FILE'])
    })

@app.route('/api/guacamole/status')
def guacamole_status():
    """Get Guacamole connection status"""
    status = validate_guacamole_connection()
    return jsonify(status)

if __name__ == '__main__':
    app.run(
        debug=app.config['DEBUG'],
        host=app.config['HOST'],
        port=app.config['PORT']
    ) 
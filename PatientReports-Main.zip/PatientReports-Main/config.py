import os
from network_config import get_guacamole_url, get_flask_url

class Config:
    """Application configuration"""
    
    # Flask settings
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'your-secret-key-change-this-in-production'
    
    # File upload settings
    UPLOAD_FOLDER = os.environ.get('UPLOAD_FOLDER') or 'data'
    MAX_FILE_SIZE = int(os.environ.get('MAX_FILE_SIZE', 50 * 1024 * 1024))  # 50MB default
    ALLOWED_EXTENSIONS = {
        'pdf', 'docx', 'xlsx', 'png', 'jpg', 'jpeg', 
        'dcm', 'txt', 'doc', 'xls'
    }
    
    # File storage
    INDEX_FILE = os.environ.get('INDEX_FILE') or 'index.json'
    
    # Guacamole integration settings
    GUACAMOLE_BASE_URL = os.environ.get('GUACAMOLE_BASE_URL') or get_guacamole_url()
    GUACAMOLE_CONNECTION_ID = os.environ.get('GUACAMOLE_CONNECTION_ID') or 'MQBjAHBvc3RncmVzcWw'
    GUACAMOLE_USERNAME = os.environ.get('GUACAMOLE_USERNAME') or 'guacaadmin'
    GUACAMOLE_PASSWORD = os.environ.get('GUACAMOLE_PASSWORD') or 'guacaadmin'
    
    # DICOM viewer settings
    SYNGOVIEW_PATH = os.environ.get('SYNGOVIEW_PATH') or 'D:\\project\\patientreport\\Syngo'
    
    # File sharing settings (for DICOM files)
    # Set this to your network share path accessible from the remote Windows session
    SHARED_FOLDER_PATH = os.environ.get('SHARED_FOLDER_PATH') or None
    
    # Development settings
    DEBUG = os.environ.get('FLASK_DEBUG', 'True').lower() == 'true'
    HOST = os.environ.get('FLASK_HOST', '0.0.0.0')  # Bind to all interfaces
    PORT = int(os.environ.get('FLASK_PORT', 5000))
    
    # Security settings
    MAX_CONTENT_LENGTH = MAX_FILE_SIZE  # Flask's built-in file size limit 
#!/usr/bin/env python3
"""
Network Configuration for Patient Reports Management System
Update these IP addresses as needed for your network setup.
"""

# =============================================================================
# NETWORK CONFIGURATION
# =============================================================================

# Your machine's IP address (WiFi IP)
# Run 'ipconfig' to find your IP address
HOST_IP = "192.168.0.173"

# Guacamole server configuration
GUACAMOLE_IP = HOST_IP  # Usually same as host IP
GUACAMOLE_PORT = 32768

# Flask application configuration
FLASK_IP = HOST_IP  # Usually same as host IP
FLASK_PORT = 5000

# =============================================================================
# GENERATED URLs (Don't edit these - they're auto-generated)
# =============================================================================

def get_guacamole_url():
    """Get the full Guacamole URL"""
    return f"http://{GUACAMOLE_IP}:{GUACAMOLE_PORT}/"

def get_flask_url():
    """Get the full Flask application URL"""
    return f"http://{FLASK_IP}:{FLASK_PORT}"

def get_guacamole_client_url(connection_id="MQBjAHBvc3RncmVzcWw"):
    """Get the Guacamole client URL"""
    return f"http://{GUACAMOLE_IP}:{GUACAMOLE_PORT}/#/client/{connection_id}"

# =============================================================================
# CONFIGURATION VALIDATION
# =============================================================================

def validate_config():
    """Validate the network configuration"""
    print("🌐 Network Configuration Validation")
    print("=" * 50)
    print(f"Host IP: {HOST_IP}")
    print(f"Guacamole URL: {get_guacamole_url()}")
    print(f"Flask URL: {get_flask_url()}")
    print(f"Guacamole Client URL: {get_guacamole_client_url()}")
    print()
    
    # Check if IP addresses are valid
    import re
    ip_pattern = r'^(\d{1,3}\.){3}\d{1,3}$'
    
    if not re.match(ip_pattern, HOST_IP):
        print("❌ Invalid HOST_IP format")
        return False
    
    if not re.match(ip_pattern, GUACAMOLE_IP):
        print("❌ Invalid GUACAMOLE_IP format")
        return False
    
    if not re.match(ip_pattern, FLASK_IP):
        print("❌ Invalid FLASK_IP format")
        return False
    
    print("✅ Network configuration is valid")
    return True

if __name__ == "__main__":
    validate_config() 
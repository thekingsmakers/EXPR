#!/usr/bin/env python3
"""
Run script for the Medical Reports Platform
"""

import os
import sys
from app import app

def main():
    """Main entry point"""
    print("🏥 Medical Reports Platform")
    print("=" * 40)
    
    # Check if data directory exists
    if not os.path.exists('data'):
        print("📁 Creating data directory...")
        os.makedirs('data', exist_ok=True)
    
    # Check if index.json exists
    if not os.path.exists('index.json'):
        print("📄 No index.json found. Creating sample data...")
        try:
            from sample_data import create_sample_data
            create_sample_data()
        except ImportError:
            print("⚠️  sample_data.py not found. Starting with empty database.")
    
    print("🚀 Starting Flask application...")
    print(f"📍 Server will be available at: http://{app.config['HOST']}:{app.config['PORT']}")
    print("📤 Upload Dashboard: /upload")
    print("👨‍⚕️ Doctor Dashboard: /doctor")
    print("🔍 Health Check: /api/health")
    print("\nPress Ctrl+C to stop the server")
    print("=" * 40)
    
    # Run the application
    app.run(
        debug=app.config['DEBUG'],
        host=app.config['HOST'],
        port=app.config['PORT']
    )

if __name__ == "__main__":
    main() 
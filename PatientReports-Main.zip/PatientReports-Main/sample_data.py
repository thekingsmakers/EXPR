#!/usr/bin/env python3
"""
Sample data generator for the Medical Reports Platform
Creates sample MRNs and file metadata for testing
"""

import os
import json
from datetime import datetime, timedelta
import random

def create_sample_data():
    """Create sample data for testing"""
    
    # Sample MRNs
    sample_mrns = [
        "MRN12345", "MRN67890", "MRN11111", "MRN22222", "MRN33333",
        "MRN44444", "MRN55555", "MRN66666", "MRN77777", "MRN88888"
    ]
    
    # Sample file types and names
    sample_files = [
        {"name": "patient_report.pdf", "type": "PDF", "size": 1024000},
        {"name": "lab_results.xlsx", "type": "Spreadsheet", "size": 512000},
        {"name": "medical_notes.docx", "type": "Document", "size": 256000},
        {"name": "xray_scan.dcm", "type": "DICOM", "size": 2048000},
        {"name": "patient_photo.jpg", "type": "Image", "size": 128000},
        {"name": "blood_work.pdf", "type": "PDF", "size": 768000},
        {"name": "prescription.docx", "type": "Document", "size": 64000},
        {"name": "ct_scan.dcm", "type": "DICOM", "size": 4096000},
        {"name": "ecg_results.xlsx", "type": "Spreadsheet", "size": 384000},
        {"name": "discharge_summary.pdf", "type": "PDF", "size": 1536000}
    ]
    
    # Create index data
    index_data = {}
    
    for mrn in sample_mrns:
        # Random number of files per MRN (1-5 files)
        num_files = random.randint(1, 5)
        mrn_files = []
        
        for i in range(num_files):
            file_info = random.choice(sample_files).copy()
            
            # Generate unique filename
            base_name = file_info["name"].split('.')[0]
            extension = file_info["name"].split('.')[1]
            unique_name = f"{base_name}_{i+1}.{extension}"
            
            # Random upload time within last 30 days
            days_ago = random.randint(0, 30)
            upload_time = datetime.now() - timedelta(days=days_ago)
            
            mrn_files.append({
                "filename": unique_name,
                "original_name": file_info["name"],
                "upload_time": upload_time.isoformat(),
                "file_size": file_info["size"],
                "file_type": file_info["type"]
            })
        
        index_data[mrn] = mrn_files
    
    # Save to index.json
    with open('index.json', 'w') as f:
        json.dump(index_data, f, indent=2, default=str)
    
    print("✅ Sample data created successfully!")
    print(f"📊 Generated {len(sample_mrns)} MRNs with {sum(len(files) for files in index_data.values())} total files")
    
    # Create sample data directories
    data_dir = "data"
    os.makedirs(data_dir, exist_ok=True)
    
    for mrn in sample_mrns:
        mrn_dir = os.path.join(data_dir, mrn)
        os.makedirs(mrn_dir, exist_ok=True)
        
        # Create placeholder files
        for file_info in index_data[mrn]:
            file_path = os.path.join(mrn_dir, file_info["filename"])
            
            # Create a simple text file as placeholder
            with open(file_path, 'w') as f:
                f.write(f"Sample {file_info['file_type']} file for {mrn}\n")
                f.write(f"Original name: {file_info['original_name']}\n")
                f.write(f"Upload time: {file_info['upload_time']}\n")
                f.write(f"File size: {file_info['file_size']} bytes\n")
                f.write("This is a placeholder file for testing purposes.\n")
    
    print("📁 Created sample data directories and placeholder files")
    print("\n🎯 You can now test the application with this sample data!")
    print("   - Upload Dashboard: http://localhost:5000/upload")
    print("   - Doctor Dashboard: http://localhost:5000/doctor")

if __name__ == "__main__":
    create_sample_data() 
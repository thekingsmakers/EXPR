#!/usr/bin/env python3
"""
Setup script for Patient Reports Management System
"""

import os
import sys
import json
from pathlib import Path

def create_env_file():
    """Create a .env file with default configuration"""
    from network_config import get_guacamole_url, get_flask_url
    
    env_content = f"""# Patient Reports Management System Configuration

# Flask Settings
SECRET_KEY=your-secret-key-change-this-in-production
FLASK_DEBUG=True
FLASK_HOST=0.0.0.0
FLASK_PORT=5000

# File Upload Settings
UPLOAD_FOLDER=data
MAX_FILE_SIZE=52428800
INDEX_FILE=index.json

# Guacamole Integration
GUACAMOLE_BASE_URL={get_guacamole_url()}
GUACAMOLE_CONNECTION_ID=SYngoServer
GUACAMOLE_USERNAME=guacaadmin
GUACAMOLE_PASSWORD=guacaadmin

# DICOM Settings
SYNGOVIEW_PATH=D:\\project\\patientreport\\Syngo

# Network Share (configure this for your setup)
# Examples:
# SHARED_FOLDER_PATH=\\\\server\\PatientFiles
# SHARED_FOLDER_PATH=\\\\192.168.1.100\\shared\\patient-files
# SHARED_FOLDER_PATH=/shared/patient-files
SHARED_FOLDER_PATH=
"""
    
    with open('.env', 'w') as f:
        f.write(env_content)
    
    print("✅ Created .env file with default configuration")
    print("📝 Please edit .env file with your specific settings")

def check_dependencies():
    """Check if required dependencies are installed"""
    try:
        import flask
        import requests
        print("✅ All required dependencies are installed")
        return True
    except ImportError as e:
        print(f"❌ Missing dependency: {e}")
        print("💡 Run: pip install -r requirements.txt")
        return False

def create_directories():
    """Create necessary directories"""
    directories = ['data', 'logs']
    
    for directory in directories:
        Path(directory).mkdir(exist_ok=True)
    
    print("✅ Created necessary directories")

def check_guacamole_connection():
    """Test Guacamole connection"""
    try:
        import requests
        from config import Config
        
        config = Config()
        response = requests.get(f"{config.GUACAMOLE_BASE_URL}", timeout=5)
        
        if response.status_code == 200:
            print("✅ Guacamole server is accessible")
            return True
        else:
            print(f"⚠️  Guacamole server responded with status {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Cannot connect to Guacamole server: {e}")
        print("💡 Make sure Guacamole is running and accessible")
        return False

def validate_configuration():
    """Validate the current configuration"""
    print("\n🔍 Validating configuration...")
    
    # Check if .env file exists
    if os.path.exists('.env'):
        print("✅ .env file found")
    else:
        print("⚠️  .env file not found - run setup again")
        return False
    
    # Check directories
    if os.path.exists('data'):
        print("✅ Data directory exists")
    else:
        print("❌ Data directory missing")
        return False
    
    # Check Guacamole connection
    guacamole_ok = check_guacamole_connection()
    
    return guacamole_ok

def main():
    """Main setup function"""
    print("🏥 Patient Reports Management System Setup")
    print("=" * 50)
    
    # Check dependencies
    if not check_dependencies():
        sys.exit(1)
    
    # Create directories
    create_directories()
    
    # Create .env file if it doesn't exist
    if not os.path.exists('.env'):
        create_env_file()
    else:
        print("✅ .env file already exists")
    
    # Validate configuration
    if validate_configuration():
        print("\n🎉 Setup completed successfully!")
        print("\n📋 Next steps:")
        print("1. Edit .env file with your specific settings")
        print("2. Set up network share for file access")
        print("3. Run: python app.py")
        print("4. Access: http://localhost:5000")
    else:
        print("\n⚠️  Setup completed with warnings")
        print("Please check the configuration and try again")

if __name__ == "__main__":
    main() 
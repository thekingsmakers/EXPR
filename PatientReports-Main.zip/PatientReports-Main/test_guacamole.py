#!/usr/bin/env python3
"""
Test script for Guacamole connection
"""

import requests
import sys
from config import Config

def test_guacamole_connection():
    """Test Guacamole connection and provide detailed diagnostics"""
    
    from network_config import get_guacamole_url, validate_config
    
    # First validate the network configuration
    validate_config()
    print()
    
    config = Config()
    base_url = config.GUACAMOLE_BASE_URL.rstrip('/')
    
    print("🏥 Guacamole Connection Test")
    print("=" * 40)
    print(f"Base URL: {base_url}")
    print(f"Connection ID: {config.GUACAMOLE_CONNECTION_ID}")
    print(f"Username: {config.GUACAMOLE_USERNAME}")
    print()
    
    # Test 1: Basic connectivity
    print("1. Testing basic connectivity...")
    try:
        response = requests.get(f"{base_url}/", timeout=5)
        print(f"   Status: {response.status_code}")
        if response.status_code == 200:
            print("   ✅ Guacamole server is accessible")
        else:
            print(f"   ⚠️  Server responded with status {response.status_code}")
    except requests.exceptions.ConnectionError:
        print("   ❌ Cannot connect to Guacamole server")
        print("   💡 Make sure Guacamole is running on http://192.168.1.104:32768/")
        return False
    except Exception as e:
        print(f"   ❌ Error: {e}")
        return False
    
    # Test 2: Try to access the client URL
    print("\n2. Testing client URL...")
    client_url = f"{base_url}/#/client/{config.GUACAMOLE_CONNECTION_ID}"
    print(f"   Client URL: {client_url}")
    
    try:
        response = requests.get(f"{base_url}/", timeout=5)
        if response.status_code == 200:
            print("   ✅ Client URL should be accessible")
        else:
            print("   ⚠️  Client URL may not be accessible")
    except Exception as e:
        print(f"   ❌ Error testing client URL: {e}")
    
    # Test 3: Check if API endpoint exists
    print("\n3. Testing API endpoint...")
    try:
        response = requests.post(f"{base_url}/api/tokens", 
                               json={'username': config.GUACAMOLE_USERNAME, 'password': config.GUACAMOLE_PASSWORD},
                               timeout=5)
        print(f"   API Status: {response.status_code}")
        if response.status_code == 200:
            print("   ✅ API endpoint is accessible")
        elif response.status_code == 401:
            print("   ⚠️  API endpoint exists but authentication failed")
        else:
            print("   ⚠️  API endpoint may not be available")
    except Exception as e:
        print(f"   ⚠️  API endpoint not available: {e}")
    
    print("\n" + "=" * 40)
    print("📋 Summary:")
    print(f"• Guacamole URL: {base_url}")
    print(f"• Client URL: {client_url}")
    print("• If connection fails, check:")
    print("  1. Guacamole is running on http://192.168.1.104:32768/")
    print("  2. Connection ID 'SYngoServer' exists in Guacamole")
    print("  3. Credentials are correct")
    print("  4. No firewall blocking the connection")
    
    return True

if __name__ == "__main__":
    test_guacamole_connection() 
#!/usr/bin/env python3
"""
IP Address Update Script for Patient Reports Management System
Run this script to easily update IP addresses in the network configuration.
"""

import os
import re
from network_config import validate_config

def get_current_ip():
    """Get the current IP from network_config.py"""
    try:
        with open('network_config.py', 'r') as f:
            content = f.read()
            match = re.search(r'HOST_IP\s*=\s*"([^"]+)"', content)
            if match:
                return match.group(1)
    except:
        pass
    return None

def update_ip_address(new_ip):
    """Update the IP address in network_config.py"""
    
    # Validate IP format
    ip_pattern = r'^(\d{1,3}\.){3}\d{1,3}$'
    if not re.match(ip_pattern, new_ip):
        print("❌ Invalid IP address format. Please use format: 192.168.1.104")
        return False
    
    try:
        # Read the current file
        with open('network_config.py', 'r') as f:
            content = f.read()
        
        # Update the HOST_IP
        content = re.sub(r'HOST_IP\s*=\s*"[^"]*"', f'HOST_IP = "{new_ip}"', content)
        
        # Write back to file
        with open('network_config.py', 'w') as f:
            f.write(content)
        
        print(f"✅ Successfully updated IP address to: {new_ip}")
        return True
        
    except Exception as e:
        print(f"❌ Error updating IP address: {e}")
        return False

def main():
    """Main function for IP update"""
    print("🌐 IP Address Update Tool")
    print("=" * 40)
    
    current_ip = get_current_ip()
    if current_ip:
        print(f"Current IP: {current_ip}")
    else:
        print("Current IP: Not found")
    
    print()
    print("To find your IP address, run: ipconfig")
    print("Look for 'IPv4 Address' under your WiFi adapter")
    print()
    
    # Get new IP from user
    new_ip = input("Enter new IP address (or press Enter to skip): ").strip()
    
    if not new_ip:
        print("No IP address entered. Exiting...")
        return
    
    # Update the IP
    if update_ip_address(new_ip):
        print()
        print("🔍 Validating new configuration...")
        validate_config()
        print()
        print("📋 Next steps:")
        print("1. Restart the application: python app.py")
        print("2. Test the connection: python test_guacamole.py")
        print("3. Access the application from other devices on the network")

if __name__ == "__main__":
    main() 